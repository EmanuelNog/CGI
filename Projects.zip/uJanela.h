//---------------------------------------------------------------------------

#ifndef uJanelaH
#define uJanelaH
//---------------------------------------------------------------------------
class Janela{
	public:
		double xmin;
		double xmax;
		double ymin;
		double ymax;

		Janela(double nxmin, double nymin, double nxmax, double nymax);
};
#endif
