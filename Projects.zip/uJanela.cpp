//---------------------------------------------------------------------------

#pragma hdrstop

#include "uJanela.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)

	Janela::Janela(double nxmin, double nymin, double nxmax, double nymax){
		xmin = nxmin;
		ymin = nymin;
		xmax = nxmax;
        ymax = nymax;

	}
